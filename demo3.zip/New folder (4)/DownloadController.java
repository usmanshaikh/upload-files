package com.infotech.flexibautomation.controller;

import java.io.IOException;
import java.util.Date;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.infotech.flexibautomation.entity.DefectHistory;
import com.infotech.flexibautomation.entity.DefectMgt;
import com.infotech.flexibautomation.entity.IssueMgt;
import com.infotech.flexibautomation.repo.DefectHistoryRepo;
import com.infotech.flexibautomation.repo.DefectMgtRepo;
import com.infotech.flexibautomation.repo.IssueMgtRepo;
import com.infotech.flexibautomation.service.FlexibService;

@Controller
public class DownloadController {
	@Autowired
	private FlexibService flexSvc;

	@Autowired
	private IssueMgtRepo issueMgtRepo;

	@Autowired
	private DefectMgtRepo defectMgtRepo;

	@Autowired
	private DefectHistoryRepo defectHistoryRepo;

	// DeclineIssue page thymeleaf
	@GetMapping(value = "/DeclineIssue/{issueId}")
	public String DeclineIssue(@PathVariable() String issueId, Model model) {
//		System.out.println("Decline issue               :  " + issueId);
		IssueMgt ISSUE = issueMgtRepo.findByIsId(issueId);
		if (ISSUE.getIssueStatus() != "Open") {
//		System.out.println(ISSUE.getIsId());
//		System.out.println(ISSUE.getComments());
////		issue.setIssueStatus("Decline");
////		issue.setUpdatedTime(new Date());
			if (ISSUE.getIssueStatus().equals(("Accepted")) || ISSUE.getIssueStatus().equals(("Declined"))) {
				System.out.println("status already............." + ISSUE.getIssueStatus());
				model.addAttribute("Decline", ISSUE);
				return "alreadyChanged";
			}
		}
		model.addAttribute("Decline", ISSUE);
		return "Decline";
	}

	// handler button Decline Action
	@PostMapping("/DeclineIssue/{issueId}")
	public String Declinedissue1(@PathVariable() String issueId, @ModelAttribute("Decline") IssueMgt issue,
			Model model) {

		System.out.println("*issueByform :" + issue);

		System.out.println("issueId  --" + issueId);
		IssueMgt oldIssue = issueMgtRepo.findByIsId(issueId);

		System.out.println("bfr comment isuue: " + oldIssue.getComments());
//		IssueMgt newIssue = new IssueMgt();

//		ModelMapper modelMapper = new ModelMapper();
//		IssueMgt issue = modelMapper.map(oldIssue, IssueMgt.class);
		oldIssue.setIssueStatus("Declined");
		oldIssue.setUpdatedTime(new Date());
		oldIssue.setComments(issue.getComments());
		System.out.println("Aftr comment isuue: " + oldIssue.getComments());
		IssueMgt newIssue = issueMgtRepo.save(oldIssue);
		System.out.println("oldIssue ::" + oldIssue);
//		System.out.println("Declinedissue ::" + Declinedissue);
		model.addAttribute("newIssue", newIssue);

		return "Decline";
	}

	// AcceptIssue thymeleaf
	@GetMapping(value = "/AcceptIssue/{issueId}")
	public String AcceptIssue(@PathVariable() String issueId, Model model) {
		System.out.println("accepted issue for defect:  " + issueId);
		IssueMgt issue = issueMgtRepo.findByIsId(issueId);
		if (issue.getIssueStatus() != "Open") {
			if (issue.getIssueStatus().equals(("Accepted")) || issue.getIssueStatus().equals(("Declined"))) {
				System.out.println("status already.." + issue.getIssueStatus());
				model.addAttribute("Decline", issue);
				return "alreadyChanged";
			}
		}
//		Project pro = projectRepo.findByProjectName(projectName);
		ModelMapper modelMapper = new ModelMapper();
		DefectMgt defect = modelMapper.map(issue, DefectMgt.class);
//	DefectMgt defectObj = new DefectMgt();
//	defectObj.setAssignedTo(defectMgtDTO.getAssignedTo());
//	defectObj.setSeverity(defectMgtDTO.getSeverity());
//		System.out.println("ddddddddddddddddd" + defect);
		defect.setStatus("Open");
		DefectMgt savedDefect = defectMgtRepo.findTopByOrderByIdDesc();

		String lastDefectMgtId = "";
		if (savedDefect == null || (savedDefect.getDefectID() == null || savedDefect.getDefectID().equals("")))
			lastDefectMgtId = "DEF_0";
		else
			lastDefectMgtId = savedDefect.getDefectID();
		int idValue = Integer
				.parseInt(lastDefectMgtId.substring(lastDefectMgtId.indexOf('_') + 1, lastDefectMgtId.length()));
		idValue++;
		System.out.println(idValue);
		defect.setDefectID("DEF_" + idValue);

//		defect.setProjectID(pro.getProjectID());
		defect.setUpdatedDate(new Date());
//		defect.setUpdatedBy(issue.);

//		UserStoryDetails us = userStoryDetailsRepo.findByTitle(defectMgtDTO.getFeatureList());
//		if (us != null)
//			defectMgt.setUsID(us.getUserStoryId());
//		try {
//			defectMgt.setFile(file.getBytes());
//			defectMgt.setFileName(file.getOriginalFilename());
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

		issue.setIssueStatus("Accepted");
		issue.setUpdatedTime(new Date());

		IssueMgt issueSave = issueMgtRepo.save(issue);

		System.out.println("issue saved.." + issueSave);

		DefectMgt saveDefect = defectMgtRepo.save(defect);

		// History code
		DefectHistory history = new DefectHistory();
		history.setComment(issue.getComments());
		history.setFile(issue.getFile());
		history.setFileName(issue.getFileName());
		history.setDefectID("DEF_" + idValue);
		history.setPostedDate(new Date());
		history.setTitle(issue.getTitle());
		history.setPostedBy(issue.getReportedby());

		defectHistoryRepo.save(history);

		System.out.println("defect saved.." + saveDefect);
		model.addAttribute("newDef", saveDefect);
		model.addAttribute("Accept", issue);
		return "Accept";
	}

	// viewIssueDetails thymeleaf
	@GetMapping(value = "/viewIssueDetails/{issueId}")
	public String viewIssueDetails(@PathVariable() String issueId, Model model) {
		IssueMgt ISSUE = issueMgtRepo.findByIsId(issueId);
		model.addAttribute("ISSUE", ISSUE);
		return "Issue";
	}

	@GetMapping("/auto")
	public String sayHello(Model theModel) {

		theModel.addAttribute("theDate", new java.util.Date());

		return "Automation";
	}

	@GetMapping("/perf")
	public String sayPerfFileDownload(Model theModel) {

		theModel.addAttribute("theDate", new java.util.Date());

		return "Performance";
	}

	@PostMapping("/checkout")
	public String sayAutomation(Model theModel) {

		System.out.println("$$$$$$ The automation method is called");
		theModel.addAttribute("theGitStatus", flexSvc.createClone());

		return "Automation";
	}

	// file download for automation page

	@GetMapping("/autodownload")
	public ResponseEntity<Resource> sayAutoFileDownload() throws IOException {

		System.out.println("$$$$$$ The download method is called for automation page");

		return flexSvc.autodownload();
	}

	// file download for performance page

	@GetMapping("/perfdownload")
	public ResponseEntity<Resource> sayPerfFileDownload1() throws IOException {

		System.out.println("$$$$$$ The download method is called for performance page");

		return flexSvc.perfdownload();

	}

}
