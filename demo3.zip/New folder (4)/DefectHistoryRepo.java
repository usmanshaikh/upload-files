package com.infotech.flexibautomation.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.infotech.flexibautomation.dto.CommentsDto;
import com.infotech.flexibautomation.dto.FileDetailsDto;
import com.infotech.flexibautomation.entity.DefectHistory;

public interface DefectHistoryRepo extends JpaRepository<DefectHistory, Integer> {
	@Query(value = "SELECT new com.infotech.flexibautomation.dto.CommentsDto(dh.comment,dh.postedBy,dh.postedDate)"
			+ "FROM DefectHistory dh where dh.defectID=:defectId AND dh.comment != ''")
	List<CommentsDto> findByDefectIDd(String defectId);

	@Query(value = "SELECT new com.infotech.flexibautomation.dto.FileDetailsDto(dh.fileName,dh.file,dh.postedDate)"
			+ "FROM DefectHistory dh where dh.defectID=:defectId AND dh.fileName is not null")
	List<FileDetailsDto> findByDefectID(String defectId);
}
